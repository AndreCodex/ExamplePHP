<?php
// Redirigir al formulario de inscripción
header("Location: Vista/vista.php");
exit();
?>